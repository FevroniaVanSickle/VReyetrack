from src.rolloutmethod import RollOutMethodInterface

def main():
    appROM = RollOutMethodInterface()
    appROM.mainloop()

if __name__ == "__main__":
    main()
